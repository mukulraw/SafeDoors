package com.technobrix.tbx.safedoors;



public class EmerBean  {

    public String title = "";
    public String number = "";


    public String getNumber() {
        return number;

    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
