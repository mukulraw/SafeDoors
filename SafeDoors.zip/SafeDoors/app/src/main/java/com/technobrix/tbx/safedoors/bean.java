package com.technobrix.tbx.safedoors;

import android.app.Application;


public class bean extends Application {

    public String userId = "";
    public String name = "";
    public String phone = "";
    public String socity = "";
    public String house_id = "";
    public String email = "";
    public String dob = "";
    public String age = "";
    public String gender = "";
    public String address = "";
    public String description = "";
    public String socity_id = "";
    public String image = "";
    public String flat = "";
    public String member_id = "";
    public String topic_id = "";
    public String vehicl_id = "";
    public String family_id = "";


}
